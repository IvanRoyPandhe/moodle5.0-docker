<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'GpFk4xuGlCuJlOnmWDYjGsflAeW8CKKclocalhost';
$CFG->bootstraphash = 'c3d96df01618fcc530dd2295505c6d2f';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
